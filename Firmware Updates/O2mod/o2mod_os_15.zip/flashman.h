/********************************************************************************************/
/* FLASHMAN (C) 2004-MrX  O2 - Internal Service Syscall Manager And Device Control  v1.0    */
/********************************************************************************************/


// ATTENTION: Under NAPLINK, the Flash programming can fail. Uses this library
// under your OWN risk. Recommended: stop the activity of the IOP in this case
// new: added a system to prevent fail under NAPLINK (not tested)

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. 
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR HOLDERS INCLUDED IN THIS NOTICE BE 
// LIABLE FOR ANY CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES, OR 
// ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER 
// IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT 
// OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.


// MEMORY MAP FOR APPLICATIONS
// START    0x20000
// PS2LOGO  0x78000  it can be used by device
// RESERVED 0x7e000  it can be used by device (reserved for one future expansion of autodetect module)
// END      0x7efff

// MAP FOR FILES         alway aligned to 4096 bytes
//  0x0    0x18  ..... 0x1000  0x1018.......0x64000 0x64018 
// |header|datas|..... |header|datas |......|header|datas|

// LOGO FORMAT
// 0x78000                            0x7e000
//|O|2|L|P|..........................| <- PAL  LOGO 344x71 8-bit gray scale
//|O|2|L|N|..........................| <- NTSC LOGO 384x64 8-bit gray scale
//<--------- 24576 bytes ------------>

// DEVICE NAME:
// The device name is oo you can load a elf for example with oo:FILE
// name limit: 16 chars, caps sensitive

// FILES RESERVED:
//
// BOOT.ELF     -> Application to launch from L2 
// BOOT.IRX     -> module to load, when oo device is mounted, it is loaded
// PS2LOGO.BIN  -> PS2LOGO is replaced with this application if LOGO CUSTOMIZED is in APP selection
// O2ATAD.IRX   -> ATAD replacement (see defines)
// O2DEV9.IRX   -> DEV9 replacement (see defines)
// O2MCMAN.IRX  -> MCMAN replacement (see defines)
// O2MCSERV.IRX -> MCSERV replacement (see defines)

// note about PS2LOGO.BIN -> it is loaded at 0x1c00000 and executed at 0x1c00008. 
// It is the binary content in a ELF file


#define TOP_ENTRIES 96
#define O2FILEMAGIC 0x02EE5555

static unsigned char flash_temp[4096]; // used to write a file

// HEADER FOR DEVICE
typedef struct 
{
unsigned id; // O2FILEMAGIC
unsigned char name[16]; 
int size;  // size of the datas (datas start to end of header)

} flash_file; // size 0x18

flash_file pfile;


// LIST ENTRIES FORMAT 

typedef struct 
{
unsigned flag; // 1-> file 0->last entry (empty entry. The offset is the first free)
unsigned offset;
unsigned size;
unsigned char name[16];
unsigned reserved;
} flash_file_list;

flash_file_list file_list[TOP_ENTRIES];
int file_is_enabled=0;

// commands
#define FLASH_ENABLE_FILES     0x555
#define FLASH_STATUS              0
#define FLASH_READ                1
#define FLASH_WRITE               2
#define FLASH_FIND_FILE           3
#define FLASH_LAST_OFFSET_FREE    4
#define FLASH_GET_ENTRIES         5
#define FLASH_ENABLE_DEVICE    0x10
#define FLASH_UPLOAD_LOGO_APP  0x11
#define FLASH_UPLOAD_MODULE    0x12
#define FLASH_SELECT_VIDEO     0x20
#define FLASH_GET_VIDEO        0x21
#define FLASH_REPLACE_MODULE   0x22
#define FLASH_CHANGE_MODE_CHIP 0x100
#define FLASH_DISABLE_SYSCALL  0x101

// video force modes
#define VFMODE_OFF        0
#define VFMODE_NTSC       1
#define VFMODE_PAL50      2
#define VFMODE_PAL60      3
#define VFMODE_VGA        4
#define VFMODE_NTSC_FIX   5
#define VFMODE_PAL50_FIX  6
#define VFMODE_PAL60_FIX  7

// replace modules
#define O2ATAD   1
#define O2DEV9   2
#define O2MCMAN  4
#define O2MCSERV 8

// chip operation modes
#define CHIP_DISABLED  0
#define CHIP_MODEPSX   1
#define CHIP_MODEPS2   2

void flash_memcpy(unsigned char *p,unsigned char *p2,int size)
{int n;
for(n=0;n<size;n++) *p++=*p2++;
}
void flash_memset(unsigned char *p,unsigned char val,int size)
{
int n;
for(n=0;n<size;n++) *p++=val;
}

// service syscall 
void Flash_Manager(unsigned command,unsigned p1,unsigned p2,unsigned p3)
{

asm volatile 
(
"
.align 4
.set noreorder
li $3,0x1000
syscall
" 
);

}

// it is used for others function to enable files commands
int Flash_File_Enable()
{
int register0;
file_is_enabled=1;
Flash_Manager(FLASH_ENABLE_FILES,0,0,0);
Flash_Manager(FLASH_STATUS,(unsigned)&register0,0,0);
if(register0==FLASH_ENABLE_FILES) return 1; // first time
return 0;
}

// int Flash_Last_Offset_Free
// arguments: point to receive the last offset

int Flash_Last_Offset_Free(unsigned *offset)
{
*offset=0;
if(!file_is_enabled) Flash_File_Enable();
Flash_Manager(FLASH_LAST_OFFSET_FREE,(unsigned)offset,0,0);
return 0;
}
// Flash_Get_Entries
// get all entries of the flash area for applications. It return 0 if is OK
// arguments: you can put 0 or one pointer to receive the entries internal list (file_list in this source)

int Flash_Get_Entries(flash_file_list **list)
{
int register0;

if(!file_is_enabled) Flash_File_Enable();
Flash_Manager(FLASH_GET_ENTRIES,(unsigned)&file_list[0],0,0);
Flash_Manager(FLASH_STATUS,(unsigned)&register0,0,0);

if(list!=0) *list=&file_list[0];
return register0;
}

// Flash_Read_File
// find the file, and read if it exist. It return 0 if is OK
// arguments: name of file (16 chars), address to put it, pointer to receive the size

int Flash_Read_File(char *name,void *addr, int *size)
{
int register0;
int off=0;
*size=0;
if(!file_is_enabled) Flash_File_Enable();
Flash_Manager(FLASH_FIND_FILE,(unsigned)name,(unsigned)&off,size);
if(off==0) return -1; else Flash_Manager(FLASH_READ,off,(unsigned)addr,(unsigned)*size);

Flash_Manager(FLASH_STATUS,(unsigned)&register0,0,0);
return register0;
}

// Flash_Write_File
// find the file and write/ create a new file. It return 0 if is OK
// arguments: name of file (16 chars), address to write, size of the datas

// WARNING: if you write a file and it exist, if the size is greater than the old size, 
// and this size write the next sector, the next file is destroy!!
//(in oo device all files are connected by a system header/datas)
// Flash_Write_File erase the sectors used before to write 

int Flash_Write_File(char *name,char *addr,int size)
{
int register0;
int off,size2;
int p,v;

if(!file_is_enabled) Flash_File_Enable();
Flash_Manager(FLASH_FIND_FILE,(unsigned)name,(unsigned)&off,(unsigned)&size2); // find the name
if(off==0) // name not exist
	{
    Flash_Manager(FLASH_LAST_OFFSET_FREE,(unsigned)&off,0,0); // find the last position free
	}
	else off&=0xff000;
if(off<0x20000) return -3; // pointer not valid
if((off+size+sizeof(pfile))>=0x7f000) return -4; // size too big
pfile.id=O2FILEMAGIC;
pfile.size=size;
flash_memcpy(pfile.name,name,16);
flash_memcpy(flash_temp,&pfile,sizeof(pfile));
p=sizeof(pfile);
while(size>0)
	{
    v=4096-p;
	flash_memcpy(flash_temp+p,addr,v);
    Flash_Manager(FLASH_WRITE,(unsigned)off,(unsigned)flash_temp,4096);
    Flash_Manager(FLASH_STATUS,(unsigned)&register0,0,0);
	if(register0!=0) return -2; // fail to write
	size-=v;addr+=v;
	off+=4096;p=0;

	}

return register0;
}

// Flash_Read
// direct flash read. It return 0 if is OK
// arguments: flash addr, buff with datas, size to read
// notes: pointers <0x20000 && >=0x7f000 they are prohibited

int Flash_Read(unsigned flash_addr,void *buff,int size)
{
int register0;


if(!file_is_enabled) Flash_File_Enable();
Flash_Manager(FLASH_READ,flash_addr,(unsigned)buff,(unsigned)size);

Flash_Manager(FLASH_STATUS,(unsigned)&register0,0,0);

return register0;
}

// Flash_Write
// direct flash write. It return 0 if is OK
// arguments: flash addr (aligned to 4096), buff with datas, size to write
// notes: pointers <0x20000 && >=0x7f000 they are prohibited
// Flash_Write erase the sectors used before to write 
int Flash_Write(unsigned flash_addr,void *buff,int size)
{
int register0;
if((((unsigned) flash_addr) & 0xfff)!=0) return -2; // pointer is not aligned to 4096

if(!file_is_enabled) Flash_File_Enable();
Flash_Manager(FLASH_WRITE,flash_addr,(unsigned)buff,(unsigned)size);

Flash_Manager(FLASH_STATUS,(unsigned)&register0,0,0);

return register0;
}

// Flash_Create_Header
// you can see how is a header for device created. The datas is after of this header
// arguments: name of the file, addr to copy the header or o to use internal header,
 // size of the datas (only the file)
int Flash_Create_Header(char *name,char *addr,int size)
{
pfile.id=O2FILEMAGIC;
pfile.size=size;
flash_memcpy(pfile.name,name,16);
if(addr) flash_memcpy(addr,&pfile,sizeof(pfile));
return sizeof(pfile);
}
// Flash_Erase_All
// example: you can erase all datas in application area using this function
int Flash_Erase_All()
{
int register0;
int off=0x20000;
if(!file_is_enabled) Flash_File_Enable();
flash_memset(flash_temp,255,4096);
while(off<0x7f000)
	{
    
    Flash_Manager(FLASH_WRITE,(unsigned)off,(unsigned)flash_temp,4096);
    Flash_Manager(FLASH_STATUS,(unsigned)&register0,0,0);
	if(register0!=0) return -2; // fail to write
	off+=4096;

	}

return register0;
}


// Flash_Enable_Device
// arguments: 1 to enable, 0 to disable
// notes: this service enable the device oo. For the load, it is necessary a IOP RESET

int Flash_Enable_Device(int onoff)
{

Flash_Manager(FLASH_ENABLE_DEVICE ,(unsigned)onoff,0,0);
return 0;
}

// Flash_Upload_LogoApp
// argument: address of binary application, size of this binary
// Load one binary application replacing PS2LOGO (it can be used from a Dashboard, if it exit to OSDSYS)
// NOTES: this application must start in 0x1c00000 Address and run from 0x1c00008
//        the max size for the application is a block of 128KB  for logoapp and module
// IMPORTANT: if you want to use a module from Flash_UploadModule you need to upload 
//            the application first
int Flash_Upload_LogoApp(void *addr,int size)
{
Flash_Manager(FLASH_UPLOAD_LOGO_APP ,(unsigned) addr,size,0);
  return 0;
}

// Flash_Upload_Module
// argument: address of module, size of this module
// Load one module in IOP, when IOP is reseting. It can be loaded when you try load other module
// NOTES: this module work in all applications when IOP is reseted
//        the max size for the module is a block of 128KB  for logoapp and module
int Flash_Upload_Module(void *addr,int size)
{
Flash_Manager(FLASH_UPLOAD_MODULE ,(unsigned) addr,size,0);
  return 0;
}

// Flash_Change_Mode_Chip
// arguments: mode of operation: 0-disabled 1-PS1 2-PS2
// NOTES:  You can turn the mode, but for  PS1/PS2 modes it need eject tray.
//         When chip is disabled, you cannot write/read the flash

int Flash_Change_Mode_Chip(int mode)
{

Flash_Manager(FLASH_CHANGE_MODE_CHIP ,(unsigned) mode,0,0);
return 0;
}

// Flash_Disable_Syscall
// It disable  this vector. If you try one access to this syscall, it fail
// NOTE: it need one exit to OSDSYS for turn on the syscall again
int Flash_Disable_Syscall()
{

Flash_Manager(FLASH_DISABLE_SYSCALL ,0,0,0);
return 0;
}

// Flash_Select_Video
// argument: video mode (see defines)
// notes: this service force the video mode in games

int Flash_Select_Video(int videomode)
{

Flash_Manager(FLASH_SELECT_VIDEO ,(unsigned) videomode,0,0);
return 0;
}

// Flash_Get_Video
// return: videomode (see defines)
// notes: this service read video mode selected

int Flash_Get_Video()
{
int videomode=0;
Flash_Manager(FLASH_GET_VIDEO ,(unsigned) &videomode,0,0);
return videomode;
}

// Flash_Replace_Module
// argument: flags for module replacement (see defines)
// notes: this service require o2 device enable and the modules in o2 device

int Flash_Replace_Module(int flags)
{

Flash_Manager(FLASH_REPLACE_MODULE ,(unsigned) flags,0,0);
return 0;
}


