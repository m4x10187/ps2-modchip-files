--
-- Script for generating CC1.0 Firmware Upgrade Images using CD-tool
--

PLAIN_FILE  = 1
BUFFER_FILE = 2
DIRECTORY   = 3

file_list = {
    { "SYSTEM.CNF", BUFFER_FILE, "BOOT2 = cdrom0:\\PS2.ELF;1\r\nVER = 1.10\r\nVMODE = NTSC\r\n" },
    { "PS2.ELF",    PLAIN_FILE,  "PS2.ELF" },
    { "FIRMWARE.CCI", PLAIN_FILE,  "FIRMWARE.CCI" },
    { "BMINST.PBT", PLAIN_FILE,  "BMINST.PBT" },
    { "BOOT",       DIRECTORY,
        {
            { "BOOT.ELF",     PLAIN_FILE,  "BOOT\\BOOT.ELF" },
            { "REDIR.IRX",  PLAIN_FILE,  "BOOT\\REDIR.IRX" },
            { "ICON.SYS",     PLAIN_FILE,  "BOOT\\ICON.SYS" },
            { "BMAN.ICN",     PLAIN_FILE,  "BOOT\\BMAN.ICN" },
            { "BM",         DIRECTORY,
                {
                    { "BMINIT.PBT", PLAIN_FILE,  "BOOT\\BM\\BMINIT.PBT" },
                    { "BOOTMENU.PBT", PLAIN_FILE, "BOOT\\BM\\BOOTMENU.PBT" },
                    { "PS1LOGO.BIN", PLAIN_FILE, "BOOT\\BM\\PS1LOGO.BIN" },
                }
            }
        }
    }
}

function process(root, files)
    for i, file in ipairs(files) do
        if (file[2] == DIRECTORY) then
            subdir = iso:createdir(root, file[1])
            subdir:setbasicsxa()
            process(subdir, file[3])
        elseif (file[2] == BUFFER_FILE) then
            tmpfile = Buffer()
            tmpfile:write(file[3])
            iso:createfile(root, file[1], tmpfile):setbasicsxa()
        elseif (file[2] == PLAIN_FILE) then
            iso:createfile(root, file[1], Input(file[3])):setbasicsxa()
        end
    end
end

function main()
    local root
    
    print "----------------------------------------------------------------"
    print "- Building Crystal Chip firmware upgrade ISO file, please wait -"
    print "----------------------------------------------------------------"

    iso:foreword(cdutil)
    pvd = createpvd(cdutil)
    pvd.sysid = "PLAYSTATION"
    pvd.volid = "CC_FIRMWARE_UPGRADE"
    pvd.volsetid = "Crystal Chip Firmware Upgrade"
    pvd.pubid = "http://www.crystal-chips.com"
    pvd.prepid = "http://www.crystal-chips.com"
    pvd.appid = "CD-Tool"
    pvd.copyright = "Crystal Chips - http://www.crystal-chips.com"
    pvd.abstract = "PLAYSTATION"
    pvd.biblio = ""

    pvd.volcreat.year = 2004
    pvd.volcreat.month = 11
    pvd.volcreat.day = 6
    pvd.volcreat.hour = 18
    pvd.volcreat.minute = 0
    pvd.volcreat.second = 0
    pvd.volcreat.hundredths = 0
    pvd.volcreat.offset = 0

    pvd.modif.year = 2004
    pvd.modif.month = 11
    pvd.modif.day = 6
    pvd.modif.hour = 18
    pvd.modif.minute = 0
    pvd.modif.second = 0
    pvd.modif.hundredths = 0
    pvd.modif.offset = 0

    pvd.voleff.year = 2004
    pvd.voleff.month = 11
    pvd.voleff.day = 6
    pvd.voleff.hour = 18
    pvd.voleff.minute = 0
    pvd.voleff.second = 0
    pvd.voleff.hundredths = 0
    pvd.voleff.offset = 0

    root = iso:setbasics(pvd)
    
    process(root, file_list)

    falsesect = {}

    for i = 1, 15000, 1 do
        iso:createsector(falsesect, MODE2_FORM1)
    end

    for i = 1, 150, 1 do
        iso:createsector(falsesect, MODE2)
    end

    iso:close()
end
