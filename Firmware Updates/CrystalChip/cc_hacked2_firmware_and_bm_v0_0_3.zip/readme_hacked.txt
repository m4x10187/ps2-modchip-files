This is hacked firmware package v0.03 for Crystal Chip CC1.0.

Burn cc-upgrade.bin using your favorite bin/cue compatible burning software(CDRWIN, Alcohol, Fireburner,
Burn-At-Once, etc). The hacked FIRMWARE.CCI file is included for those who want use alternate methods to 
update the firmware.

Notes on upgrading:

After installing your CC1.0, burn the upgrade disc and boot it as you would a normal PS2 disc.  You will
get a screen with 2 options: "Install BMan" and "Flash Chip".  First choose "Flash Chip" to program the firmware
to your chip, watch the screen and it will tell you after 20-30 seconds if it was successful or failed.  If failed,
simply choose "Flash Chip" again.

When done flashing the chip, choose "Install BMan" to install BootManager to your memory card in slot 1.  !Make
sure you have at least 100k free on your memory card!  When this is complete it will say done! or failed!

After installation is complete, you may reset the PS2 and BootManager will automatically start up.
