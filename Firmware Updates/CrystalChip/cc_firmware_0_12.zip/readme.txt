Crystal Chips - http://www.crystal-chips.com/

This is the CC1.0 software release 12.

Included in this package are CC1.0 firmware source codes, support tools, BootManager and associated
scripts and applications.

Release History:

Release 12 -
        Firmware Changes:
            Slight changes to the PS2 bootstrap.

        BootManager Changes:
            New Features:
                PS2 Software:
                    - Configurable X *and* Y positioning modifiers with individual settings for PAL and
                        NTSC games for perfect screen positioning!  Please note that this is a very new
                        feature and may have bugs.  Also, some games will NOT like having their vsync
                        forced and will crash, but this should be a low number of games.

                PS1 Software:
                    - Greater seperation of NTSC and PAL game settings allowing disabling of fixes for
                        one type, without disabling the other.

                PBAT Interpreter:
                    - Added "FORMAT" command.  Be careful with this, you don't want to erase
                        your memcard on accident. :)
                        FORMAT "mc0:"
                    - Added "CDSTOP" command.  This will stop the CD/DVD from spinning.
                        CDSTOP

                Application Browser:
                    - Added "Failed!" text display if Run/Install/Remove of applications fails.

                Miscellaneous:
                    - Added support for CodeBreaker9(and perhaps version 7 and 8).  Note that this
                        will NOT work with copies of CB9 software, only the original CB9 disc.

            Bug Fixes/Changes:
                Autoload should work all the time now, the timer will now reset when you press a button
                    in the Main Menu but will not stop.  So if you don't want it to autoload, disable it!

                Fixed color carrier bug in PS2 software.

                Fixed a bug where switching from one disc to another inside BM would result in failure
                    to read the new disc and occasionally lock up BM.

                Fixed 2 bugs where returning from the DVD player would result in DVD Video discs not being
                    correctly detected.

                Removed stopping of the disc spinning when disc is idle as it slows down booting and can
                    potentially cause problems with normal operation.  You may add "CDSTOP"(see above)
                    to your RUN.PBT scripts for applications if you desire for the CD to stop spinning
                    when running a specific application.

Release 11 -
        BootManager Changes:
            Bug Fixes:
                - Fixed a bug where PBAT scripts would fail when using labels under certain conditions,
                    often resulting in the Boot Menu not working.

Release 10 -
        BootManager Changes:
            New Features:
                - ! IMPORTANT ! PBAT variables must now be specified as $VAR$ instead of $VAR as it had been
                    in previous versions.  This means that ALL PBAT files must be updated.

                - ! IMPORTANT ! FLASHER.ELF will remove the BOOT directory and all files/directories contained
                    in it if a previous version of BM was installed to avoid conflicts with the old script
                    system and avoid wasting space on your memory card.

                - Individual Boot Scripts(PS1BOOT.PBT, PS2BOOT.PBT, etc) have all been replaced by a single
                    scriptable Boot Menu(BOOTMENU.PBT) which allows for much greater customization of how your
                    disc booting is handled.

                - Software controlled Sleep Mode is scripted in the BOOTMENU.PBT

                - The disc will now stop spinning when idle.

                - Added ability to remove BOOT directory and all sub-directories from Memory Card 2 to the
                    Memory Card Manager.

                - Each PBAT script is now run as it's own "session", this changes the following behaviors:
                    You no longer need to UNSET all variables at the end of your script.  However, it is
                        recommended that you unset variables if you have a large number of variables in
                        your script as any given script can only have a total of 128 local variables.
                    You can LOADEXEC other PBAT files from within your PBAT file without having variable
                        conflicts.
                    You cannot share LOCAL variables with other scripts any longer.

                - Added "SETENV" command to PBAT.  "SETENV" allows you to create a variable which are shared
                    with all sessions:
                    SETENV "MY_SHARED_VAR" "My shared value"

                - Added "IFNOT" and "ELSEIFNOT" commands to PBAT.  They work just the way they sound,
                    if the condition is NOT met, the code following will be executed.

                - Added "EXISTS" operator to PBAT "IF" and "ELSEIF" commands:
                    IF "cdrom0:\PS2.ELF" "EXISTS" ...

                - Added "GOTO" command to PBAT. IMPORTANT NOTE: Do NOT use GOTO to jump to a label which is
                    within an IF statement! Doing so will result in script failure.

                - Added support for labels to PBAT(Note: labels only work with "GOTO")

                - Added "GETDISKTYPE" command to PBAT.
                    GETDISKTYPE "MY_VAR"

                - Added "SETBIOS" command to PBAT.
                    SETBIOS "PS2"

                - Added "PARSECNF" command to PBAT.
                    PARSECNF "cdrom0:\SYSTEM.CNF" "BOOT_NAME" "BOOT_TYPE"

                - Added "LOADSRAM" command to PBAT.
                    LOADSRAM "mc0:/BOOT/BM/PS1LOGO.BIN"

                - Added "EXIT" command to PBAT.
                    EXIT "0"

                - Added "PEEKB", "PEEKH", "PEEKW", "POKEB", "POKEH", "POKEW" commands to PBAT.
                    PEEKB "0x1F40200F" "MY_VAR_NAME"
                    POKEW "0x00101234" "0x12"

            Bug Fixes:
                - Fixed icon filename case so BM icon shows up properly in PS2 browser.

                - Fixed bug where last line of a PBT file would not be executed unless it ended in a newline.

                - Fixed bug where "SHUTDOWN" command did not work properly.

Release 9 -
        This is just a release to fix a mistake in the "cc-iso-builder.lua" file included in
            Release 8 as well as a typo in FLASHER.ELF.  These bugs would cause installation of
            BootManager to fail when installing from disc.

Release 8 -
        BootManager Changes:
            - Added BM memory card icon to software package, BM icon now shows up when viewing
                memory card in PS2 browser.

            - Fixed a bug when manually loading a disc if autoload was disabled.

            - Added disc icon for BMI(BootManager Installer) discs.

            - Fixed bug causing ATAD Auto-Patcher and potentially other features to fail.

            - Added Video Stabilizer DVD Video Enhancement which allows removal of Macrovision
                for improved video quality.

            - BM is now completely independant of the firmware for disc validation, instead using
                4 different boot scripts:
                    BOOTPS1.PBT <- PS1 disc boot script
                    BOOTPS2.PBT <- PS2 disc boot script
                    BOOTDVDV.PBT <- DVD Video boot script
                    BOOTCDDA.PBT <- CD Digital Audio("Audio CD") boot script.

            PBAT:
                - Fixed bug with variable names shorter than 3 characters(and perhaps other places).

                - Added IF(EQU, NEQ, ISIN), ELSEIF(EQU, NEQ, ISIN), ELSE and ENDIF commands to PBAT.

                - Added SETAUTH and CYCLETRAY commands to PBAT.

                - Added RRM and RCOPY commands to PBAT. NOTE: RRM and RCOPY will only work on file systems
                    that support directory access functions.

            - Many little changes, fixes, etc...

        Firmware Changes:
            - Integration of UCL N2E unpacker(written by Pixel taken as part of ps2-packer) allow for
                compression of the firmware to fit more code and data.

            - LOADER.S is now only used to load another binary out of CC EEPROM, unpack and execute it.

            - OSDHOOK.S replaces parts of the old LOADER.S and all of VALIDATOR.S.

            - Firmware no longer provides a method for homebrew applications to determine disc validation.

        Other Changes:
            - New CCIGEN.EXE with integrated OSDSYS Hook packer.

            - CCIGEN source is available for download from the official Crystal Chips website at
                http://www.crystal-chips.com/

            - New FLASHER.ELF supporting installation of latest BM.ELF and scripts.

Release 7 -
        BootManager Changes:
            Implemented new Application Installer Menu system.
            Fixed a problem with force video fixes in some games.
            Fixed miscellaneous bugs/texts.

Release 6 -
        BootManager Changes:
            Fixed another bug with the DVD Video "Green Screen Fix".  Seems to work perfectly now.

Release 5 -
        BootManager Changes:
            Fixed configuration bug for PS1 Disc Speed, PS1 Texture Mapping and DVD Video "Green Screen Fix".
            Added CD Digital Audio(CDDA) bootstrap, BM will now execute the PS2 browser for CD audio discs.
            Fixed configuration bug for autoload disc settings.

Release 4 -
        Made a small change to CCHW.S.
        Fixed a couple bugs in BM causing lockups when booting discs on some consoles as well as a bug
        in he path for install scripts.

Release 3 -
        Added ability to disable tray cycling for DVD videos if not required by player.
        Partially combined loader.s and ps2boot.s, split remainder of functionality into
        validator.s.
        Added cd-tool by Pixel for automating upgrade image generation.
        Removed HOSTUPG.ELF, PS2.ELF can be run from either host or cdrom.

Release 2 -
        Fixed macros.inc path in ps1logo.s
        Fixed file name in PS2.ELF
        Added HOSTUPG.ELF

Release 1 -
        Initial release.

This documentation is not the best, we'll improve it as time goes on.

Included in this package is the application ASM5900 by wiRe of the group Napalm.  We take no credit for
the creation of this application.  In addition, you may download this application from his site at
http://wire.napalm-x.com/.  There was no license file included in the release so there is none included
here.

CCIGEN.EXE is an application written by Crystal Chips for generating CCI firmware images for use with
the Crystal Chip hardware.  Any other uses are strictly prohibited.  You may freely distribute this package
in whole, or in part provided you retain this file and do not remove or modify any of the credits.  Use
of CCIGEN or associated applications is at your own risk.  Crystal Chips is not responsible for any damages
caused directly or indirectly by the use of these applications.  That is not to say there is any malicious
code in our software, only that if something goes wrong, we will not take responsibility.  Source code for
CCIGEN is available for download from the official Crystal Chips website at http://www.crystal-chips.com/

cd-tool is written by Pixel and is packaged with our firmware with his permission.  This tool allows you to
generate upgrade images easily using the "makeit.bat" file.

FLASHER.ELF utilizes gsKit, an open-source graphics library written by Neovangelist which is available from
PS2DEV.org.

BootManager and some other PS2 applications we provide use the basic open-source ps2sdk created by members of
the PS2DEV community.  You can download ps2sdk and many other great bits of code from the official PS2DEV
website at ps2dev.org.  These guys are responsible for there being a way to create homebrew apps, feel free to
let them know that you appreciate what they do.

To build the Crystal Chip firmware and upgrade disc image:

Extract all files to the same folder.

If you wish to make changes to the source or boot scripts, now is the time to do it.

Run the "makeit.bat" file.  This will generate "FIRMWARE.CCI" as well as "cc-upgrade.bin" and "cc-upgrade.cue"
files.

Burn cc-upgrade.bin using your favorite bin/cue compatible burning software(CDRWIN, Alcohol, Fireburner,
Burn-At-Once, etc).

Notes on upgrading:

After installing your CC1.0, burn the upgrade disc and boot it as you would a normal PS2 disc.  You will
get a screen with 2 options: "Install BMan" and "Flash Chip".  First choose "Flash Chip" to program the firmware
to your chip, watch the screen and it will tell you after 20-30 seconds if it was successful or failed.  If failed,
simply choose "Flash Chip" again.

When done flashing the chip, choose "Install BMan" to install BootManager to your memory card in slot 1.  !Make
sure you have at least 200k free on your memory card!  When this is complete it will say done! or failed!

After installation is complete, you may reset the PS2 and BootManager will automatically start up.

Notes on upgrading from host(naplink/ps2link/etc):

After running the "makeit.bat" file, you can simply run "flasher.elf" with naplink/ps2link and use the upgrade
application the same way you would if you had booted from cd.
