To create an upgrade disc:

Generate a Mode 2 ISO with FIRMWARE.CCI, PS2.ELF, SYSTEM.CNF all on the root of the disc.

Burn the disc and boot it in your PS2 with the CC1.0 hardware installed.

To upgrade from ps2link/naplink:

Run HOSTUPG.ELF from naplink/ps2link with the FIRMWARE.CCI file in the same folder.  Follow the same instructions
as before.

Notes on upgrading:

While upgrading, your screen will first show white, then blue.  After 30 seconds or so(be patient), it will
turn green or red.  Green means that it was successful, red means that it failed.  We have yet to encounter
a failure but it's possible that it could happen sometime, somewhere to someone. If this happens, simply
reset your PS2 and let the upgrade disc boot again.
