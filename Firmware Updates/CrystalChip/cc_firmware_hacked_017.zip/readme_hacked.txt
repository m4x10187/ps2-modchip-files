  ____                _        _    ____ _     _         ____  _ _____ 
 / ___|_ __ _   _ ___| |_ __ _| |  / ___| |__ (_)_ __   |  _ \/ |___  |
| |   | '__| | | / __| __/ _` | | | |   | '_ \| | '_ \  | |_) | |  / / 
| |___| |  | |_| \__ \ || (_| | | | |___| | | | | |_) | |  _ <| | / /  
 \____|_|   \__, |___/\__\__,_|_|  \____|_| |_|_| .__/  |_| \_\_|/_/   
            |___/                               |_|                    
 _                _            _    __ _                                      
| |__   __ _  ___| | _____  __| |  / _(_)_ __ _ __ _____      ____ _ _ __ ___ 
| '_ \ / _` |/ __| |/ / _ \/ _` | | |_| | '__| '_ ` _ \ \ /\ / / _` | '__/ _ \
| | | | (_| | (__|   <  __/ (_| | |  _| | |  | | | | | \ V  V / (_| | | |  __/
|_| |_|\__,_|\___|_|\_\___|\__,_| |_| |_|_|  |_| |_| |_|\_/\_/ \__,_|_|  \___|

This is hacked binary firmware package R17 Beta for Crystal Chip.

The hacked FWARE10.CCI (CC1.0), FWARE11.CCI (CC1.1) and FWARE20.CCI (CC2.0)
files are included for those who want to use alternate methods to update the
firmware. Also included the hacked source files.

Make sure that you follow the steps below STRICTLY. You may cause damage if
you don't. This is still a beta-release.

2005-11-17: modrobert @ http://www.eurasia.nu

---
Burn cc-upgrade.bin using your favorite bin/cue compatible burning software
(CDRWIN, Alcohol, Fireburner, Burn-At-Once, etc). 

Important: Crystal Chip will autodetect the firmware disc and will load the
'Main Menu'. Please follow these steps strictly in the order they are listed:

Step 1: Insert Memory Card
Step 2: Insert firmware disc
Step 3: Install Bootmanager v1.7
Step 4: Upgrade firmware
Step 5: Put console in standby mode
Step 6: Turn console on again to enter Bootmanager v1.7

Do not upgrade new firmware before Bootmanager v1.7 was installed on the
inserted memory card. Please follow this advise to avoid the risk of damage.

