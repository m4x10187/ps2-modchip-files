
Crystal Chips - http://www.crystal-chips.com/

This is the CC1.0 software release 9.

Included in this package are CC1.0 firmware source codes, support tools, BootManager and associated
scripts and applications.

Release History:

Release 9 -
        Release 8 had a typo in FLASHER.ELF and was missing entries for 2 file entries in
            "cc-iso-builder.lua".  These bugs would cause installation of BootManager to
            fail when installing from disc.  This release resolves that issue, no other changes
            were made.

Release 8 -
        BootManager Changes:
            - Added BM memory card icon to software package, BM icon now shows up when viewing
                memory card in PS2 browser.

            - Fixed a bug when manually loading a disc if autoload was disabled.

            - Added disc icon for BMI(BootManager Installer) discs.

            - Fixed bug causing ATAD Auto-Patcher and potentially other features to fail.

            - Added Video Stabilizer DVD Video Enhancement which allows removal of Macrovision
                for improved video quality.

            - BM is now completely independant of the firmware for disc validation, instead using
                4 different boot scripts:
                    BOOTPS1.PBT <- PS1 disc boot script
                    BOOTPS2.PBT <- PS2 disc boot script
                    BOOTDVDV.PBT <- DVD Video boot script
                    BOOTCDDA.PBT <- CD Digital Audio("Audio CD") boot script.

            PBAT:
                - Fixed bug with variable names shorter than 3 characters(and perhaps other places).

                - Added IF(EQU, NEQ, ISIN), ELSEIF(EQU, NEQ, ISIN), ELSE and ENDIF commands to PBAT.

                - Added SETAUTH and CYCLETRAY commands to PBAT.

                - Added RRM and RCOPY commands to PBAT. NOTE: RRM and RCOPY will only work on file systems
                    that support directory access functions.

            - Many little changes, fixes, etc...

        Firmware Changes:
            - Integration of UCL N2E unpacker(written by Pixel taken as part of ps2-packer) allow for
                compression of the firmware to fit more code and data.

            - LOADER.S is now only used to load another binary out of CC EEPROM, unpack and execute it.

            - OSDHOOK.S replaces parts of the old LOADER.S and all of VALIDATOR.S.

            - Firmware no longer provides a method for homebrew applications to determine disc validation.

        Other Changes:
            - New CCIGEN.EXE with integrated OSDSYS Hook packer.

            - CCIGEN source is available for download from the official Crystal Chips website at
                http://www.crystal-chips.com/

            - New FLASHER.ELF supporting installation of latest BM.ELF and scripts.

Release 7 -
        BootManager Changes:
            Implemented new Application Installer Menu system.
            Fixed a problem with force video fixes in some games.
            Fixed miscellaneous bugs/texts.

Release 6 -
        BootManager Changes:
            Fixed another bug with the DVD Video "Green Screen Fix".  Seems to work perfectly now.

Release 5 -
        BootManager Changes:
            Fixed configuration bug for PS1 Disc Speed, PS1 Texture Mapping and DVD Video "Green Screen Fix".
            Added CD Digital Audio(CDDA) bootstrap, BM will now execute the PS2 browser for CD audio discs.
            Fixed configuration bug for autoload disc settings.

Release 4 -
        Made a small change to CCHW.S.
        Fixed a couple bugs in BM causing lockups when booting discs on some consoles as well as a bug
        in he path for install scripts.

Release 3 -
        Added ability to disable tray cycling for DVD videos if not required by player.
        Partially combined loader.s and ps2boot.s, split remainder of functionality into
        validator.s.
        Added cd-tool by Pixel for automating upgrade image generation.
        Removed HOSTUPG.ELF, PS2.ELF can be run from either host or cdrom.

Release 2 -
        Fixed macros.inc path in ps1logo.s
        Fixed file name in PS2.ELF
        Added HOSTUPG.ELF

Release 1 -
        Initial release.

This documentation is not the best, we'll improve it as time goes on.

Included in this package is the application ASM5900 by wiRe of the group Napalm.  We take no credit for
the creation of this application.  In addition, you may download this application from his site at
http://wire.napalm-x.com/.  There was no license file included in the release so there is none included
here.

CCIGEN.EXE is an application written by Crystal Chips for generating CCI firmware images for use with
the Crystal Chip hardware.  Any other uses are strictly prohibited.  You may freely distribute this package
in whole, or in part provided you retain this file and do not remove or modify any of the credits.  Use
of CCIGEN or associated applications is at your own risk.  Crystal Chips is not responsible for any damages
caused directly or indirectly by the use of these applications.  That is not to say there is any malicious
code in our software, only that if something goes wrong, we will not take responsibility.  Source code for
CCIGEN is available for download from the official Crystal Chips website at http://www.crystal-chips.com/

cd-tool is written by Pixel and is packaged with our firmware with his permission.  This tool allows you to
generate upgrade images easily using the "makeit.bat" file.

BootManager and some other PS2 applications we provide use the basic open-source ps2sdk created by members of
the PS2DEV community.  You can download ps2sdk and many other great bits of code from the official PS2DEV website
at ps2dev.org.  These guys are responsible for there being a way to create homebrew apps, feel free to let them
know you appreciate what they do.

To build the Crystal Chip firmware and upgrade disc image:

Extract all files to the same folder.

If you wish to make changes to the source or boot scripts, now is the time to do it.

Run the "makeit.bat" file.  This will generate "FIRMWARE.CCI" as well as "cc-upgrade.bin" and "cc-upgrade.cue"
files.

Burn cc-upgrade.bin using your favorite bin/cue compatible burning software(CDRWIN, Alcohol, Fireburner,
Burn-At-Once, etc).

Notes on upgrading:

After installing your CC1.0, burn the upgrade disc and boot it as you would a normal PS2 disc.  You will
get a screen with 2 options: "Install BMan" and "Flash Chip".  First choose "Flash Chip" to program the firmware
to your chip, watch the screen and it will tell you after 20-30 seconds if it was successful or failed.  If failed,
simply choose "Flash Chip" again.

When done flashing the chip, choose "Install BMan" to install BootManager to your memory card in slot 1.  !Make
sure you have at least 200k free on your memory card!  When this is complete it will say done! or failed!

After installation is complete, you may reset the PS2 and BootManager will automatically start up.

Notes on upgrading from host(naplink/ps2link/etc):

After running the "makeit.bat" file, you can simply run "flasher.elf" with naplink/ps2link and use the upgrade
application the same way you would if you had booted from cd.
