This is hacked binary firmware package R15 for Crystal Chip CC1.0.

The hacked FIRMWARE.CCI file is included for those who want to use alternate
methods to update the firmware. Also included the hacked source files by 
agentboolen for reference.

2005-07-19: modrobert @ http://www.eurasia.nu

---

Burn cc-upgrade.bin using your favorite bin/cue compatible burning software
(CDRWIN, Alcohol, Fireburner, Burn-At-Once, etc).

Notes on upgrading:

Step 1: Insert the Upgrade Disc into your PS2 and let it start up.
Step 2: Choose "Install Firmware" and wait for it to complete.
Step 3: If you wish to use BootManager(highly suggested!), make sure you have
        a memory card inserted in Slot 1 and choose "Install BootManager" then
        wait for it to complete.
Step 4: Reboot your PS2, you're all done!

