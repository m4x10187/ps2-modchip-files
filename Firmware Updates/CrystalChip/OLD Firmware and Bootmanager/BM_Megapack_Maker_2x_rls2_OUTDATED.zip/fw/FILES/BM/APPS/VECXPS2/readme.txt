VecX for PS2 (version 0.2)
~~~~~~~~~~~~~~~~~~~~~~~~~~

By James Higgs (aka Jum) 2006

VecXPS2 is a port of Valavan Manohararajah's Vectrex emulator.

It's a first release, so don't expect perfection.

It ONLY RUNS ROMS OFF OF A MEMORY STICK!

I've added basic audio emulation (AY3-8190 chip), analog stick support, 
and a vector "persistence" blending effect, but it's not perfect.

It's free, so if you paid for it, then you got ripped off.

And of course you use it completely at your own risk.


Important:

To run this emulator, you need to be able either:
1. Boot a CDR on your PS2, OR...
2. Load a homebrew ELF file on your PS2 (naplink, ps2link, independance 
   exploit, etc).


Getting Started:

1. Get a flash drive (also called a memory stick or memory key)
2. Make a folder called "Vectrex" on the flash drive
3. Copy some Vectrex game roms into the "Vectrex" folder
4. Plug the flash drive into your PS2
5. Boot the VECXPS2 CDR, OR...
5. Run the VECX.ELF executable program on your PS2


Other Info:

My older Transcend JetFlash 128 doesn't work with VecXPS2 (something to 
do with the PS2 USB_MASS code), but my newer 1Gig key (Mecer) does work.


Thanks to...
Valavan M for making VecX code portable
The usual suspects in ps2dev for maplink, independance exploit, sbv_patch 
lib, usb_mass lib etc etc.



Source code available on request.
james7780 @ yahoo.com







