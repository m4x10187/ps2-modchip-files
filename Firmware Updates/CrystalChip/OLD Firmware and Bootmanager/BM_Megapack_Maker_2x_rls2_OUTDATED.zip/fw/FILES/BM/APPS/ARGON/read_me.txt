

Developers

If you want to help the project, here are the main tasks:
- SMS playback functions, if you are able to understand EEUG's code, I'm not, so I'm waiting for him to give me some clues,
- threads, semaphores, timers and stuff like that,
- high quality mp3 decoder (libmad maybe? - haven't tested it yet) - while SMS mp3 decoder is ok for movies (speed is more important there), for plain mp3's we can use something better,
- Shoutcast support,
- SMB support - http://ntba2.de/?p=libsmb, if it's performance will be adequate,
- DAAP support (iTunes sharing),
- AAC decoder - FAAC?
- visualization - based on something like that http://imagesavant.com/ or http://flam3.com/ (this one is opensource) or something else, but it should be extremely minimalistic (and I don't care about it reacting to the music),
- zlib support for those bitmaps and fonts,
- better icons.
These are more or less in the order of their priority. Contact me if you are interested.


Argon v0.2

- Requires an internet connection.
- Edit Argon.xml to define folders to be parsed - <music> and <photo> (you can add several entries), and the path to uLaunchELF.
- Weather (using the service provided by The Weather Channel) - working. Edit Argon.xml to set you location (here is an explanation on how to obtain your location ID: http://www.xml.com/pub/a/2004/09/29/weather.html). Pressing X on the weather screen will display a satellite image.
- Radio � categories list implemented.
- Photo - working, but libjpeg is damn slow. Thumbnails are shown for only the first five JPEGs (to speedup loading). Left/right - previous/next.
- Music � thumbnails implemented (folder.jpg or AlbumArtSmall.jpg).
- Still single threaded - takes ages to load...


Argon v0.1

- Nothing, except the menu itself, is working, not even thumbnails.
- No support for CD/DVD and HDD, only host: and USB (so, you can only start it from there).
- No media change notifications - only parses folders at startup.

Controls - directional buttons, X - confirm, O - cancel.


