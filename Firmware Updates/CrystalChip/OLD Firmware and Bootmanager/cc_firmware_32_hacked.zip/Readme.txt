______________________________________________________________________________
******************************************************************************
*********************** Germany never Sleeps Project *************************
******************************************************************************
##############################################################################


      /MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\
 www./MMMM-hitman43-Cagefighter-FusionSTUDIOS-MMMM
    /MMMM-Tok708-modchipmaster-Dawn2k-Jones23-MMMM
    MMMMM-Arakon-123456-whynot-doctormord-Ede-MMMM
    MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    MMMMMMMMM/                              MMMMMM
    MMMMMMMMM                               MMMMMM
    MMMMMMMMM       MMMMMMMMM\          /MMMMMMMMM
    MMMMMMMMM       MMMMMMMMMM\        /MMMMMMMMMM
    MMMMMMMMM       MMMMMMMMMMM\      /MMMMMMMMMMM
    MMMMMMMMM       MMMMMM\MMMMM\    /MMMMM/MMMMMM
    MMMMMMMMM       MMMMMM \MMMMN\  /MMMMM/ MMMMMM
    MMMMMMMMM       MMMMMM  \MMMMM\/MMMMM/  MMMMMM
    MMMMMMMMM\      MMMMMM   \MMMMMMMMMM/   MMMMMM
    MMMMMMMMMM\     MMMMMM    \MMMMMMMM/    MMMMMM
    MMMMMMMMMMM\    MMMMMM     \MMMMMM/     MMMMMM
    MMMMMMMMMMMM    MMMMMM      MMMMMM      MMMMMM
    MMMMMMMMMMMM    MMMMMM      MMMMMM      MMMMMM
    MMMMMMMMMMMM    MMMMMM      MMMMMM      MMMMMM
    MMMMMMMMMMMM
    MM/      \MM MMMMVMMM   /MM   MMM MMM /MMMMMM\ MMM         /MMMMMM /MMMMMM\ MMMMMMVMMMM\
    MM        MM  MMMVMMM MMMMMMM MMM/MMM MMMMMMMM MMM         MMM     MMMMMMMM  MMMM\M/MMMM
    MM   MM   MM  MMM MMM MMMMMMM MMMV/   MMM  MMM MMM         MMM     MMM  MMM  MMM MMM MMM
    MM   MM   MM  MMM MMM   MMM   MMMM    MMM  MMM MMM         MMM     MMM  MMM  MMM MMM MMM
    MM        MM  MMM MMM   MMM   MMM     MMMMMMMM MMM     MM  MMM     MMMMMMMM  MMM MMM MMM
    MM\      /MM  \MM MMMM  \MMMM \MM     \MMMMMM/ \MMMMMM MM  \MMMMMM \MMMMMM/  \MM MMM MMMM
    MMMMMMMMMMMM                            MMMMMM       GermanysMultiConsoleSceneScoure#Nr.1
    MMMMMMMMMMMM                            MMMMMM
    MMMMMMMMMMMM                            MMMMMM
    MMMMMMMMMMMM\                          /MMMMMM
    MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    MMMMMMMM---> www.modcontrol.com <---MMMMMMMMM/
    \MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM/
     \MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM/
      *****************************************

_______________________________________________________________________________
*******************************************************************************
-------> powered by:   www.gamfreax.com  /  www.tamultimedia.de    <-----------
-------> www.gamestore24.de /  www.heo.com  /  www.wolfsoft.de     <-----------
-------> www.gametop.de  /  www.freaxstore.de  /  www.freakware.de <-----------
*******************************************************************************
###############################################################################
_______________________________________________________________________________
*******************************************************************************
*****************-----CrystalChip Software 32 hacked-----**********************
***************************--02.02.2007--**************************************
###############################################################################

Details:
    This hacked Firmware allows you to play backup PS1 and PS2 games.
    For details about the changes refer to the cc_readme.txt. If you experience
    problems during the update, look at the cc_upgrade.txt.

Instructions:
    Burn the bin/cue image to CD using your favorite burn software (e.g. Nero).
    Boot the disc in your PS2 and install firmware and BootManager.

    For more detailed burning instructions refer to:
    http://crystal-chips.com/main/content/view/70/62/

_______________________________________________________________________________
*******************************************************************************
###############################################################################
_______________________________________________________________________________
*******************************************************************************
***************************---- Credits: -----*********************************
*******************************************************************************
###############################################################################
www.xbox-scene.com, www.maxconsole.com,www.xboxhacker.net,www.ps2-scene.org,
www.gueux.be,www.teamxecuter.com,www.teamxodus.com,www.teamxchanger.com,
www.infinitymod.com,www.crystal-chips.com,www.dms3.com,www.qoobchip.com,
www.vipergcextreme.com,www.teamxtender.com,www.m3adapter.com,www.neoflash.com,
www.dvd2xbox.xbox-scene.com,www.smartxx.com and all other sites we forgot!!!!!!
*******************************************************************************
###############################################################################
Copyright: www.modcontrol.com
###############################################################################
