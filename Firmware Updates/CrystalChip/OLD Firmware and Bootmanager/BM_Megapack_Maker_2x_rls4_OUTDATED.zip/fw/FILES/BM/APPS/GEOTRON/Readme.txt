GEOTRON PS2 (alpha version 0.3a)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

21 February 2005

This is the 3rd "work in progress" release of Geotron for PS2.

It's a version of a simple old skool arcade game called "Geometry Wars" for XBox.

It's far from finished. Some missing features are:
- Improved player death/explosion effect
- Game Over display
- Black hole gravity effect
- Sound effects still need to be tweaked
- 2 player (simultaneous and alternating)
- Player ship design needs to be finalised
- more...

Plus it's got a few of bugs (one bad bug causes the game to freeze after playing for about 3 minutes). 

You might have some fun with it anyway.

This release can be run off a memory card (tested) and probably a CDR (not tested yet).

It's NTSC only.

You need a dual shock controller to play it.

Use the left analog stick to steer, and the right analog stick to fire.
Press L1 or R1 to use a smart bomb.

The analog sticks are "calibrated" when the game is loaded, so don't touch the analog sticks as the game is loading. During the game, if your player ship moves or fires without you touching the analog sticks, then you can recalibrate by pressing L2 AND R2 while not touching the sticks.

Please email me some feedback / suggestions regarding:
- How it works on your PS2
- Gameplay and graphic differences between Geotron and "Geometry Wars"
- Any suggestions regarding gameplay, graphics or sound
- How to make it more fun

If enough people think it's got potential, I'll make it open-source.

Compiled using ps2sdk 1.1, gsKit, and my own EE sound lib.
Many thanks to the ppl involved in bringing us ps2sdk and gsKit.
Keep up the good work :)
Also thanks to those who already gave some feedback.

- Jum 21/2/2005
email: james7780@yahoo.com
