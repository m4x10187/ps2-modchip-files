This is firmware source code package v0.02 for Crystal Chip CC1.0.

Changelog:

v0.02 - Fixed macros.inc path in ps1logo.s
        Fixed file name in PS2.ELF
        Added HOSTUPG.ELF
v0.01 - Initial release.

This documentation is not the best, we'll improve it as time goes on.

Included in this package is the application ASM5900 by wiRe of the group Napalm.  We take no credit for
the creation of this application.  In addition, you may download this application from his site at
http://wire.napalm-x.com/.  There was no license file included in the release so there was none included
here.

CCIGEN.EXE is an application written by Crystal Chips for generating CCI firmware images for use with
the Crystal Chip hardware.  Any other uses are strictly prohibited.  You may freely distribute this package
in whole, or in part provided you retain this file and do not remove or modify any of the credits.  Use
of CCIGEN or associated applications is at your own risk.  Crystal Chips is not responsible for any damages
caused directly or indirectly by the use of these applications.  That is not to say there is any malicious
code in our software, only that if something goes wrong, we will not take responsibility.


To build the Crystal Chip firmware:

Extract all files to the same folder.

Run the "makeit.bat" file.

This will generate a file "FIRMWARE.CCI"


To create an upgrade disc:

Generate a Mode 2 ISO with FIRMWARE.CCI, PS2.ELF, SYSTEM.CNF all on the root of the disc.

Burn the disc and boot it in your PS2 with the CC1.0 hardware installed.

To upgrade from ps2link/naplink:

Run HOSTUPG.ELF from naplink/ps2link with the FIRMWARE.CCI file in the same folder.  Follow the same instructions
as before.

Notes on upgrading:

While upgrading, your screen will first show white, then blue.  After 30 seconds or so(be patient), it will
turn green or red.  Green means that it was successful, red means that it failed.  We have yet to encounter
a failure but it's possible that it could happen sometime, somewhere to someone. If this happens, simply
reset your PS2 and let the upgrade disc boot again.
