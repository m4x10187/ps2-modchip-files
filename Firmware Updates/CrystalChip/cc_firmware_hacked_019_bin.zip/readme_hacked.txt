  ____                _        _    ____ _     _         ____  _  ___  
 / ___|_ __ _   _ ___| |_ __ _| |  / ___| |__ (_)_ __   |  _ \/ |/ _ \ 
| |   | '__| | | / __| __/ _` | | | |   | '_ \| | '_ \  | |_) | | (_) |
| |___| |  | |_| \__ \ || (_| | | | |___| | | | | |_) | |  _ <| |\__, |
 \____|_|   \__, |___/\__\__,_|_|  \____|_| |_|_| .__/  |_| \_\_|  /_/ 
            |___/                               |_|                    
 _                _            _    __ _                                      
| |__   __ _  ___| | _____  __| |  / _(_)_ __ _ __ _____      ____ _ _ __ ___ 
| '_ \ / _` |/ __| |/ / _ \/ _` | | |_| | '__| '_ ` _ \ \ /\ / / _` | '__/ _ \
| | | | (_| | (__|   <  __/ (_| | |  _| | |  | | | | | \ V  V / (_| | | |  __/
|_| |_|\__,_|\___|_|\_\___|\__,_| |_| |_|_|  |_| |_| |_|\_/\_/ \__,_|_|  \___|

This is hacked binary firmware package R19 for Crystal Chip.

The hacked FWARE10.CCI (CC1.0), FWARE11.CCI (CC1.1) and FWAREDF.CCI (CC2.0)
files are included for those who want to use alternate methods to update the
firmware. 

2005-12-20: modrobert @ http://www.eurasia.nu

----

Burn cc-upgrade.bin using your favorite bin/cue compatible burning software
(Nero, CDRWIN, Alcohol, Fireburner, Burn-At-Once, etc).

Notes on upgrading:

Step 1: Insert the Upgrade Disc into your PS2 and let it start up.
Step 2: Choose "Install Firmware" and wait for it to complete.
Step 3: If you wish to use BootManager(highly suggested!), make sure you have
        a memory card inserted in Slot 1 and choose "Install BootManager" then
        wait for it to complete.
Step 4: Reboot your PS2, you're all done!

