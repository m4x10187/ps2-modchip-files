=========================================
Readme for DMS3 Flash v2.3 Beta 0 Release
=========================================

How to use
----------

Burn the upgrade BIN/CUE to CD-R and boot, then follow the onscreen directions.

The configuration menu
----------------------

 To enter the configuration menu hold down the shoulder buttons
 (L1 + L2 + R1 + R2) on controller 1 as the PS2 is booting. Once
 in the configuration menu you can enable/disable settings, select the
 default boot mode and see various version data such as your PS2 version,
 flash version etc.

 Default boot mode can be set to "Normal", "Fast Boot", "Dev.olution 1"
 and "Dev.olution 2". If you are not holding down a button on controller
 1 when your PS2 is booting to select the boot mode, then DMS3 will use
 the default boot mode which has been set by the configuration menu
 (if there is no memory card in slot 1 then DMS3 will use Normal boot).

 NOTE: Settings are stored on a memory card in slot 1. If you do not
       have a memory card inserted then you will not be able to save
       your settings, and DMS3 will use the default settings when you boot.

Notes on HDD support
--------------------

 In order to use a non-Sony HDD with HDD-enabled games, you must first 
 enable the ATAD auto patching using the configuration menu.

 The recently released HDD + FFXI bundle is now supported by DMS3. The
 new support means that it is possible to boot games from the updated
 browser (you dont need to use fast boot any longer!) - however, in 
 order to launch the PlayOnline Viewer you MUST disable your DMS3 by 
 placing your console in standby, then holding EJECT for a few seconds. 
 You cannot launch the PlayOnline Viewer when the DMS3 is enabled.

Notes on the PS2 video fix
--------------------------

 The PS2 video fix is selectable between three modes:

  - None: PS2 video fix is disabled
  - Colour Carrier: The colour carrier of the video signal is changed to
    match the region of your console.
  - Video Mode: The video mode output by the PS2 is changed to match the
    region of your console (ie: force PAL or force NTSC).
 
========================
ChangeLog for DMS Flash:
========================

2.3 Beta 0 Release:
-------------------

 * Fixed some games freezeing (Jak 2, etc)
 * Settings can now be read from MM16 card
 * Language is set to English when using Fast Boot, so games dont display in Japanese

2.2 Release:
------------

 * Fixed an issue which caused certain games to freeze
 * Improved reliability of flash updater application
 * Added support for Codebreaker original discs
 * PS2 video fix is now selectable between colour carrier fix, or video mode (PAL/NTSC).

2.0 Release:
------------

 * Problem with V9+ consoles booting DVD-R media fixed
 * Support for the official US HDD (retail, BETA was already supported)
 * DMS configuration menu added. Now possible to enable/disable settings,
   select the default boot mode and check PS2, DMS3 and Flash version info
 * You can now force all games to use the native video mode of your console (PAL, NTSC)
 * Auto-ATAD patching added. You can now play HDD enabled games on a
   non-Sony HDD, without patching the game disc
