=========================================
Readme for DMS3 Flash v2.4 Beta 6 Release
=========================================

How to use
----------

Burn the upgrade BIN/CUE to CD-R and boot, then follow the onscreen directions.

The configuration menu
----------------------

 To enter the configuration menu, hold down the L1 button on controller
 1 as the PS2 is booting. Once in the configuration menu you can 
 enable/disable settings, select the default boot mode and see various 
 version data such as your PS2 version, flash version etc.

 Default boot mode can be set to "Normal", "Fast Boot", "Dev.olution 1"
 and "Dev.olution 2". If you are not holding down a button on controller
 1 when your PS2 is booting to select the boot mode, then DMS3 will use
 the default boot mode which has been set by the configuration menu
 (if there is no memory card in slot 1 then DMS3 will use Normal boot).

 NOTE: Settings are stored on a memory card in slot 1. If you do not
       have a memory card inserted then you will not be able to save
       your settings, and DMS3 will use the default settings when you boot.

Notes on HDD support
--------------------

 In order to use a non-Sony HDD with HDD-enabled games, you must first 
 enable the ATAD auto patching using the configuration menu.

 The recently released HDD + FFXI bundle is now supported by DMS3. The
 new support means that it is possible to boot games from the updated
 browser (you dont need to use fast boot any longer!) - however, in 
 order to launch the PlayOnline Viewer you MUST disable your DMS3 by 
 placing your console in standby, then holding EJECT for a few seconds. 
 You cannot launch the PlayOnline Viewer when the DMS3 is enabled.

Notes on the PS2 video fix
--------------------------

 The PS2 video fix is selectable between four modes:

  - None: PS2 video fix is disabled
  - Colour Carrier: The colour carrier of the video signal is changed to
    match the region of your console.
  - Force PAL: PAL video mode is forced (50Hz). The vertical position of the 
    display is also corrected.
  - Force NTSC: NTSC video mode is forced (60Hz). The vertical position of 
    the display is also corrected.
  - PAL60: The PS2 is forced to output video as PAL60 (60hz with PAL
    colour carrier). The vertical position of the display is also corrected.

Notes on DMS HDD Explorer
-------------------------

As of DMS3 firmware 2.4 beta 5, the use of HDD Explorer has been disabled. If
you wish to continue using HDD Explorer do not upgrade your firmware.
The reason we decided to disable this is as follows:

HDD Explorer writes to the DMS3 flash to save settings related to loading HDD
Explorer. This has been proven to be an unreliable way of doing things for the
DMS3 series modchips - quite a few people have had problems. DMS is now working
on a new DMS explorer which we hope to release in the near future. This new
version will not need to write anything to the modchip flash so will not suffer
from the same problems as the current version (NOTE: DMS4 is not effected by this
problem due to more reliable flash manipulation methods). The new version will
also boast some pretty cool features, so keep your eyes out!
 
========================
ChangeLog for DMS Flash:
========================

2.5 Beta 6:

 * Re-added support for HDD Explorer (using new loading method).
 * Cleaned up some code, should help entering config screen.

2.4 Beta 5:

 * Major code cleanup/maintenance, hopefully will fix problems with some games.
 * Video mode fix improved overall, also added "Force PAL" and "Force NTSC".
 * Settings are now saved into a dedicated directory/save on the memory card 
   rather than the BRDATA-SYSTEM directory. There shouldn't be any config 
   related problems with any console region now.
 * Partially working "Codebreaker fix" removed until a more reliable solution
   is found.
 * As noted above, HDD Explorer is disabled for now.

2.4 Beta 4:

 * Fixed progressive scan in the DVD player
 * Fixed configuration saving for Asian consoles
 * Fixed a bug which prevented a few games from working properly

2.4 Beta 3:

 * Added Y-position fix
 * Added PAL60 mode to PS2 video fix

2.4 Beta 2:

 * Fixed game language problem *PROPERLY* this time ;)

2.4 Beta 1:

 * Fixed game language problem with fastboot
 * Changed button combo to enter config menu (now just press L1)
 * Configuration tool complains if memory card not present

2.4 Beta 0:
-----------

 * Fixed booting HDDExplorer on DMS3+
 * Added "Codebreaker Fix" to configuration menu
 * Hopefully fixed ARMAX Evo (untested - please test people!)

2.3 Release:
------------

 * Support added for DMS3 Plus
 * Fixed some games freezeing (Jak 2, etc)
 * Settings can now be read from MM16 card
 * Language is set to English when using Fast Boot, so games dont display in Japanese
 * Fixed problem with auto-ATAD patching
 * Fixed problem with Colour Carrier fix
 * ARMAX is now working with backups

2.2 Release:
------------

 * Fixed an issue which caused certain games to freeze
 * Improved reliability of flash updater application
 * Added support for Codebreaker original discs
 * PS2 video fix is now selectable between colour carrier fix, or video mode (PAL/NTSC).

2.0 Release:
------------

 * Problem with V9+ consoles booting DVD-R media fixed
 * Support for the official US HDD (retail, BETA was already supported)
 * DMS configuration menu added. Now possible to enable/disable settings,
   select the default boot mode and check PS2, DMS3 and Flash version info
 * You can now force all games to use the native video mode of your console (PAL, NTSC)
 * Auto-ATAD patching added. You can now play HDD enabled games on a
   non-Sony HDD, without patching the game disc
