
=======================
MX4 FIRMWARE V1.00
=======================




BURNING TO CD:
--------------

- Create a directory on your desktop or other location of your HD.
- Unzip the ".cue" and ".bin" files present inside the .zip file into this directory.
- Open your preferred burning program (Nero, alcohool120%, etc etc.) and choose
  option to burn a "CD-ROM ISO".
- Press the file selection button and choose file type "Image Files (.cue)".
- Navigate to the directory where you unzipped the V1.00 files and select the 
  "mx4fw100.cue" file.
- Burn the CD.


UPGRADING MX4:
--------------

- Put Upgrade CD into PS2 and put PS2 into standby.
- Press "reset button" and keep pressed until blue light turn ON (on V1-V11).
  (For the V12 press reset button from standby for 2-3 seconds as there is no blue light).
- Leave "reset button" and Upgrade CD will boot.
- Follow on-screen instructions to complete the Upgrade procedures.


- NOTE : You can always recover from a bad flash by hoding the reset button until
  ====   the blue eject light turns on. This will let you boot the upgrade disc
         to reflash your MX4.



STANDARD OPERATION FOR THE MATRIX MX4:
======================================

BOOT OF PS2 / PS1 / DVD MOVIES: 
-------------------------------

- Insert the disc inside the PS2.
- The MX4 will recognize the kind of disc you inserted and select
  the appropriate boot system.


TURNING OFF THE MX4:
--------------------

- Press START on joypad 1 until the writing "DISABLED" will appear on screen. 
- Press reset once.
- The MX4 is now disabled until PS2 is turned off to Standby Position.


FAST BOOT OF PS2 GAMES: 
-----------------------

- Press SELECT on joypad 1.
- PS2 Logo will be skipped and game will boot directly.





---

If you have any suggestion, or would like to leave us a comment, feel 
free to mail your suggestions at: info@infinitymod.com and
