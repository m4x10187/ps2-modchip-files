
			 ��������                                               
                      ���  ��� � �ܰ                                            
 ����� �����������۲���  ߱�� ���  ۰� ���۰  �  ����  ��۲ �   ��������۰      
   ��  ������������۰� � �� �  �  � ۰ ����۰   ���۰  ����  ���������۲��      
   �       ����۰   � ���  �� �  ��� �  ����۰ ���۰   ���� ������۰ ����۰     
        �   ����    �  � ��    �� � ��   ����۰����    ���� ����۰              
    � ����� ����   �۰��   �  �  ��� ۰   �������۰    ���� ���۰     ����      
     ������ ���� � �۱� � ����� �� ��۰ �  �����۰  �  ���� ����   ��������     
  � �����   ����    �ܰ    ����    ���  �  �����۰  �� ���� ����    �������     
   �������  �۲� �  �� ���� �� ���� ۰ �  �������۰    ���� ���۰  �  � ���     
   �������� ����    �  �����  ���۰  �   ����۰�۲۰ � �۲� ����۰  �    ��     
   �   � �  �۲�  �  ��     ��     ��   ����۰ ����۰  ���� �����۰             
   �  �     �۲� ��� � ۰ ����߰ �� �  ����۰   �۲�۰ �۲� `��۲��۰����۰     
  �۱       �۲� ����  �۰ ���� �۰    �����  �  �۲�� �۲�  ���۲��������      
 ���۱      ����  ����  ۱� �� ���     ���۰ ��� ����� ����    ���������۰      
  �۱                   ��������߰           �                                  
   �        ����                   �  �������۲ ������� ���    �����������      
   �       ������       ���������      ��۱��� ������� ����   ������ �          
         ���������� � ��������������    �۲��������     ���� �������   �        
     �����������������  ���������     ����۲�  �������  ���   �������������     
 ������  ���������� � �  �������   � �  �۱   �������������������ܱ�����������  
                                                               ���۲��          
                  -= ToxicOS v0.2 Release =-                    �����          
                                                                 ���
Introduction
============

ToxicOS is a third party flash upgrade for the DMS4 Pro modchip by Team Toxic.
While providing all the features of ToxicBIOS, it also provides a host of
innovative new features such as the ability to run games from the HDD.
Currently ToxicOS is in the early stages of development and many of the 
planned features have yet to be implemented - however, we're sure you will love
what ToxicOS can do so far.. and dont forget, more features will be added with
each new release :)

Current features provided by ToxicOS are as follows:

- Run PS2 games directly from your HDD. This leads to decreased loading times
  and makes gaming so much more convenient. Never again will you need to endure
  those painfully slow loading times!
- Auto-detect and non-swap booting of all disc types (PS2, DVD, PSX, etc)
- Compatible with all PS2 models V1-V12
- Dev.olution mode (from memory card and HDD)
- DVD region free, Macrovision removal and green screen fix for the DVD player
- Auto-ATAD patching for HDD-enabled games
- Fast boot mode for PS2, PSX and DVD movies
- Support for the HDD browser upgrade on a non-Sony HDD
- Set default boot mode to: Normal, MC/HDD Dev.olution, Fast Boot
- Playstation 2 game video fix (Colour Carrier, PAL, NTSC, PAL60), with
  automatic y-position correction
- Playstation 1 game video fix
- Enable MegaMemory memory cards without the need for the boot disc
- Configuration menu where various settings can be manipulated
- "Toxic" logo displayed at the PS2 logo screen
- When booting from Dev.olution mode or Fast Boot, games use correct language
- Modchip disable mode, for online gaming
- Support for the Codebreaker cheat device
- 100% boot rate

Features planned for future releases include:

- Integrated cheat device, allowing you to use cheats while playing games
  from the HDD or CD/DVD without requiring a 3rd party cheating product.
- 48-bit LBA support which will allow HDD's larger than 137GB to be fully
  utilised.
- Support for installing DVD-9 games to the HDD.
- The ability to launch PS2/PSX games and DVD movies directly from ToxicOS,
  turning it into a complete browser replacement.
- The ability to manipulate console settings such as screen size, date/time
  from inside of ToxicOS.
- Support for installing homebrew applications to the HDD or memory card. This
  will provide similar functionality to DMS Explorer/CC BootManager etc.
- Some suprises which we know you'll love!

*****************************************************************************
NOTE: All HDD related features are unsupported on the PStwo (V12) console at
      the current time.
*****************************************************************************

Detailed Feature Overview
=========================

-> Run games from the HDD!

   Using ToxicOS you can install and run games directly from a HDD connected
   to your PS2. When you boot into ToxicOS you will be presented with the
   main screen, composed of the game list and toolbar. From here you can:

   a) Play games already installed on your HDD
   b) Install a new game to your HDD
   c) Remove a game from your HDD
   d) Rename a game on your HDD
   e) View information for a specific game and change game settings

   At the main screen either the game list or toolbar is in focus at any one
   time. You can alternate focus with the LEFT and RIGHT buttons on the D-pad.
   When the game list is in focus the key mapping is as follows:

   UP/DOWN	- Select game
   CROSS	- Start playing the selected game
   TRIANGLE	- View info/settings for selected game
   L1		- Scroll page up
   R1		- Scroll page down

   When the toolbar is in focus, use the LEFT/RIGHT buttons to select an
   action and CROSS to choose that action. If you select install you will
   be taken to the installation screen. Here you will be asked to insert a 
   CD or DVD and then enter a name for the game using the onscreen keyboard.
   While at the onscreen keyboard the key mapping is as follows:

   D-pad	- Move selection
   CROSS	- Make selection
   START	- Shortcut for ENTER key
   CIRCLE	- Shortcut for CANCEL key
   L1		- Move cursor left
   R1		- Move cursor right
   L2		- Shortcut for BACKSPACE key
   R2		- Shortcut for SHIFT key

   Enter the name of the game then select ENTER to continue. Now the game
   will be installed to the HDD - and this can take a while, so be patient :)

   The rename and remove options in the toolbar are self-explanatory so no
   need to cover them here. The settings option will bring up the game info/
   settings dialog. From here you can see game information and change the
   compatibility mode settings. Some games require special compatibility modes
   to be set in order for those games to work correctly. More information
   regarding these compatibility modes will be made available shortly.

-> Dev.olution mode

   Using Dev.olution mode you can boot applications from either the memory
   card or hard disk drive. When booting in MC Dev.olution mode, the ELF file
   "mc0:/BOOT/BOOT.ELF" is launched. This ELF file can be anything you want, 
   such as DMS Explorer, PS2Menu, PS2OS etc. To boot in MC Dev.olution mode
   either hold down TRIANGLE on controller 1 while the PS2 is booting, or
   set default boot mode to MC Dev.olution in the configuration menu. Currently
   the only application which can be launched with HDD Dev.olution mode is
   DMS HDD Explorer. Once HDD Explorer is installed, you may boot in HDD
   Dev.olution mode by either holding down START on controller 1 while the PS2
   is booting, or set default boot mode to HDD Dev.olution in the configuration
   menu.

   NOTE: From ToxicOS v0.2 and up you must use DMS HDD Explorer v1.3 or
         greater. Older versions are no longer supported.

-> ATAD auto-patching

   When ATAD auto-patching is enabled, you can connect a non-Sony HDD to your
   PS2 and use it as though it was an official Sony drive. You will be able
   to install and use the HDD browser update (found on the HDD utility disc) on
   a non-Sony HDD, and you will be able to partially install some games with
   HDD support to improve performance.. even though this is a bit pointless
   with the existence of ToxicOS ;)

-> Fast boot mode

   Fast boot mode allows you to skip the redundant "swirling electrons" and
   various logo screens and directly load your PS2/PSX game or DVD movie as 
   soon as you turn on the console, saving valuable time which would be better 
   spent gaming. To use fast boot mode, either hold down SELECT while the PS2 
   is booting or set default boot mode to fast boot in the configuration menu.

-> Default boot mode

   Using the configuration menu you can set the default boot mode to one of the
   following: Normal, ToxicOS, Fast Boot, MC Dev.olution, HDD Dev.olution. If 
   you do not manually specify a boot mode while the PS2 is booting by holding 
   down a button on controller 1, the default boot mode will be used. For 
   example if the default boot mode is set to MC Dev.olution, when you turn on 
   the PS2 without holding down any buttons on the controller, your MC Dev.olution
   application will be loaded from the memory card. If you then wish to boot
   normally (i.e.: boot through standard browser) hold down CROSS on controller
   1 while booting to over-ride the default boot mode.

-> Playstation 2 game video fix

   There are 4 different modes for the PS2 video MODE fix, as described below:

   - Colour Carrier: The colour carrier of the video signal is changed to
     match the region of your console.
   - Force PAL: Video mode forced to PAL (50hz), regardless of what video mode
     games try to set.
   - Force NTSC: Video mode forced to NTSC (60hz), regardless of what video
     mode games try to set.
   - Force PAL60: Video mode forced to PAL60, which is 60hz with PAL colour
     carrier.

   In addition to the PS2 video MODE fix, you can also enable the PS2 video
   Y-POS fix. The y-position fix is used in conjunction with the PS2 video
   MODE fix in order to correct the vertical position of the display. For
   example, simply focing PAL when a NTSC game is running will generally result
   in the display being far off center. The y-position fix corrects this and
   centers the display. Please note that the y-position fix is not available
   when the PS2 video MODE fix is off or set to Color Carrier, since in these
   cases the video mode is not forced so the display position will not need
   to be corrected. Please note that the y-position fix feature should still
   be considered EXPERIMENTAL and has been known to cause problems with a few
   games. If a game isnt working, disable the y-position fix and see if this
   helps.

   You can configure the PS2 video MODE and PS2 video Y-POS fixes in the
   configuration menu.
   
-> Configuration Menu

   The configuration menu is used to manipulate various ToxicOS settings, for
   example enabling or disabling ATAD auto-patching. The configuration menu also
   displays useful information about your PS2 system and DMS4 modchip. To enter
   the configuration menu, hold down SQUARE on controller 1 while the PS2 is
   booting.

-> Disable Mode

   When playing online games it is often necessary to disable the modchip so you
   do not get a DNAS error while connecting to the online game server. To
   disable DMS4, hold down L1 on controller 1 as the PS2 is booting. You will
   see a message saying that the modchip has been disabled. Insert your game and
   reset the console - the modchip will not be disabled and will stay disabled
   until the PS2 is placed in standby.

-> Codebreaker cheat device support

   The more recent codebreaker cheat devices include a protection system which
   is designed to detect the presence of modchips and prevent the application
   from working on a modified system. ToxicOS bypasses this protection and
   allows codebreaker to work properly, however you must first set
   "Auto Tray Eject" to OFF in the options menu.

Boot-time controller mapping
============================

When the console is booting, holding down certain buttons on controller 1 will
activate certain modes/features. These are listed below:

   CROSS    - Use standard boot (over-ride default boot mode setting)
   R1       - Boot into ToxicOS
   TRIANGLE - MC Dev.olution mode
   START    - HDD Dev.olution mode
   SELECT   - Fast boot mode
   SQUARE   - Load configuration menu
   L1       - Disable modchip

How to Install
==============

Installation directions vary depending on boot method:

- ELF boot: Simply execute the ELF using your favorite loader application 
  (PS2Menu, PS2Link, Naplink, PS2OS, LaunchELF etc) and follow the on-screen 
  directions.

- CD boot: Simply burn the BIN/CUE provided, boot the disc and follow the
  on-screen directions.

Frequently Asked Questions
==========================

Q: How do I boot into ToxicOS?
A: Hold R1 while booting the PS2 or set the default boot mode to "ToxicOS".

Q: Can I disable the "Toxic" logo displayed under the Playstation 2 logo when
   booting PS2 games?
A: Yes. Set "Display Toxic Logo" to NO in the configuration menu.

Q: Why do I get the "TV system doesn't match" error while trying to play a
   DVD movie?
A: You will be presented with this error if you attempt to play a PAL movie on
   a NTSC console. This is due to a limitation in the DVD player software and
   currently there is no way around this. We are looking into ways to fix this
   and hopefully a fix will be included in a future ToxicOS release.

Q: I have a feature request or bug report for Team Toxic. How can I contact you?
A: We do not provide any contact details such as e-mail addresses etc, however 
   we do monitor various "scene" forums so if you have a request or a problem
   then just make a post and there is a good chance we will see it and take note
   of it :)

Q: I have a game which isnt loading or working prorperly. What can I do?

   1) Disable y-position fix if it is enabled. This is still experimental and
      has been known to cause problems with a few games.
   2) Make sure that the game is burnt on good quality media at an appropriate
      speed. If your PS2's laser cannot read from your disc, the game will
      obviously not work.

Q: There is already 48-bit LBA support in some other PS2 HDD applications, why
   dont you just use the same method they do for 48-bit support?
A: The current 48-bit LBA solution is not a nice one. It means if you want to
   use the 48-bit enabled ATA driver you need to patch ALL your HDD-enabled
   applications to use this. You cannot mix use of the 28-bit and 48-bit drivers.
   This is due to the APA partition system, which works in such a way that if
   the 48-bit LBA driver is used to create a partition over the 137GB boundary
   then if you try and use the 28-bit LBA driver on the same HDD the PS2 will
   crash. We are currently working on a more novel, reliable solution to this
   problem which will enable you to store games over the 137GB boundary without
   breaking compatibility with applications which only support 28-bit LBA. Stay
   tuned for more information!

Q: I have heard that some code was "stolen" in order to create ToxicOS, is this
   true?!
A: NO NO NO! People who say this are just trying to brainwash you in a sad
   attempt to hurt Team Toxic. The TRUTH is NOTHING was stolen, as I will explain.
   Its true that ToxicOS contains code from the open source projects ps2lib, 
   ps2drv and libhdd however this DOES NOT mean that we have stolen any code! 
   These open source projects are licensed in such a way that anybody can use 
   them for anything they want be it commercial projects, freeware projects, 
   open source or closed source! The only requirement is that the copyrights 
   of the original authors remain intact, this requirement has been met with 
   the license file supplied with this release. Other than the projects 
   mentioned above, ALL OTHER CODE in ToxicOS was developed by Team Toxic - 
   its our code, it belongs to us, and we can do with it as we see fit.

Q: Will the source code for ToxicOS ever be released?
A: No. We dont feel it would be a good idea to release source code since then
   it would make it far too easy for certain groups to use our software for 
   their own financial gain by including it with their own products. Certain 
   HK companies will rip just about anything if they get a chance (even stuff 
   like Naplink.. "bootable Naplink CD's" anyone?) - so lets not give them 
   that opportunity :)

Version Information
===================

ToxicOS consists of ToxicBIOS at its core (which means it has all the same
features as ToxicBIOS) and the actual OS application. The version numbers 
for these components in this ToxicOS build are as follows:

BIOS v1.2
OS software v0.1

Change Log
==========

 0.2 Release:

 * Updated core BIOS to ToxicBIOS v1.2, which includes the following changes:
   - Fastboot can now also load PSX games and DVD movies
   - Improved authentication logic which leads to significantly improved boot 
     rates on consoles with poor lasers
   - Codebreaker cheat devices are now supported
   - Manual y-position fix toggle and gui enhancements added to configuration menu
   - Progressive scan while PS2 video fix enabled is now working
   - Added support for DMS HDD Explorer v1.3. Older versions are no longer 
     supported.
   - Other minor bugfixes and code cleanup
 * Fixed a bug which caused a black screen on reset after playing PSX games
 * There have been no changes to the OS software in this build

 0.1 Release:
 ------------

 * Initial release!

Group News
==========

ToxicOS v0.3 is coming soon! Features planned for the upcoming release include:

- Integrated cheat device, allowing you to use cheats while playing games
  from the HDD or CD/DVD without requiring a 3rd party cheating product.
- The ability to launch PS2/PSX games (not stored on the HDD) and DVD movies
  directly from ToxicOS, so you dont need to boot into the browser or fastboot
  mode in order to launch such discs.
- Improved compatibility for running games from the HDD.
- All the new features present in this ToxicBIOS release.
- 48-bit LBA support *if we get time*.

Miscellaneous
=============

ToxicOS may be hosted by anybody, anywhere - PROVIDED that the archive
remains unaltered and that it is not used in ways its not supposed to be!

Oh, and props to the DMS team for making such a nice modchip - even though
the flash they ship with the chip sucks and cant do much of anything :P
