===============================
DMS4 Official Flash Release 0.4
===============================

How to use
----------

Either:

- Burn the upgrade BIN/CUE to CD-R and boot, then follow the onscreen directions
- Execute the provided ELF file using your favourite loader program, and follow
  onscreen directions.

NOTE: This flash upgrade is compatible with BOTH DMS4 Lite and Pro modchips.


DMS4 Flash Features
-------------------

- Autodetect disc type
- Boot homebrew applications
- DVD region free with green screen removal
- MC and HDD Dev.olution mode. Run homebrew applications directly from the
  memory card or HDD.
- Modchip disable mode


While the console is booting, holding down certain buttons on controller
1 will activate certain features as described below:

  TRIANGLE - MC Dev.olution mode
  START    - HDD Dev.olution mode
  SQUARE   - Disable modchip

========================
ChangeLog for DMS Flash:
========================

0.4 Release:

 * Added fastboot for homebrew PS2 discs
 * Added support for DMS HDD Explorer v1.3+. Older versions are
   no longer supported.

0.2 Release:

 * Initial release.
