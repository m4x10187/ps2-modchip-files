
=======================
INFINITY FIRMWARE V1.31
=======================


What's new :
------------

- AUTO force mode.
- Infinity configuration screen position fix for some NTSC TVs.
- MC_LOADER issues fixed.


Notes :
-------

- It is now possible to force Infinity AUTO mode when a different default mode
  is selected in the option scren.
  If, for example, you have set DEV1 mode as the default boot on powerup, but
  you want to boot from CD without changing mode in the option screen, you can
  now do this by pressing the CROSS pad button after reset.

- The Infinity configuration screen should now be centered on all NTSC television.

- There was a small problem when loading the mediaplayer from Mcloader when both
  programs were run from the cdrom. This is now fixed.




Infinity option configuration menu :
------------------------------------

Press PAD + CIRCLE to enter the configuration menu.


PS2 SCREEN FIX   : OFF    : Disables PS2 video fix.

                   COLOR  : Games will be output on their original video mode (PAL/NTSC)
                            with color correction applied to match your PS2 region.

                   VMODE  : Force video mode to match your PS2 region.

                   PAL60  : Force all games to NTSC with color correction.
                            Games will run faster but screen might need adjusting.

PSX SCREEN FIX   : ON/OFF : Enable/Disable PSX screen fix

MC16 PATCH       : ON/OFF : Enable/Disable D4TEL memory card support

ATAD AUTO PATCH  : ON/OFF : Enable/Disable ATAD auto patch

MACROVISION FIX  : ON/OFF : Enable/Disable Macrovision patch

GREEN FIX        : ON/OFF : Enable/Disable green correction on DVD movies

BOOT MODE        : AUTO   : Normal behaviour. All discs wil autoboot.

                   FAST   : FastBoot.
                            Same as pressing SELECT on boot.

                   INFMAN : Execute Infinity Manager on mc0:
                            Same as Pressing TRIANGLE on boot.

                   DEV1   : Execute BOOT.ELF on mc0:
                            Same as Pressing R1 on boot.
 
                   DVDV   : Force DVD video mode.
                            Same as Pressing CIRCLE on boot.

PAD DETECT TIME  : 2..10  : Select time to wait for connected pad on boot.
                            Only useful if pad is left unconnected.

DEFAULT LANGUAGE : LANG   : Default language to use for FastBoot/InfMan/Dev1 mode.




BURNING TO CD:
--------------

- Create a directory on your desktop or other location of your HD.
- Unzip the ".cue" and ".bin" files present inside the .zip file into this directory.
- Open your preferred burning program (Nero, alcohool120%, etc etc.) and choose
  option to burn a "CD-ROM ISO".
- Press the file selection button and choose file type "Image Files (.cue)".
- Navigate to the directory where you unzipped the V1.31 files and select the 
  "infv131.cue" file.
- Burn the CD.


UPGRADING INFINITY:
-------------------

- Insert the burned CD into the PS2 and press reset.
  The CD should boot authomatically and you will be presented with the Upgrade sreen.
- Follow instructions on screen to upgrade Infinity.

- NOTE : You can always recover from a bad flash by hoding the reset button until
  ====   the blue eject light turns on. This will let you boot the upgrade disc
         to reflash your Infinity.



STANDARD OPERATION FOR THE MATRIX INFINITY:
===========================================

BOOT OF PS2 / PS1 / DVD MOVIES: 
-------------------------------

- Insert the disc inside the PS2.
- The infinity will recognize the kind of disc you inserted and select
  the appropriate boot system.


TURNING OFF THE INFINITY:
-------------------------

- Press START on joypad 1 until the writing "DISABLED" will appear on screen. 
- Press reset once.
- The Infinity is now disabled until PS2 is turned off to Standby Position.


FAST BOOT OF PS2 GAMES: 
-----------------------

- Press SELECT on joypad 1.
- PS2 Logo will be skipped and game will boot directly.


FORCING PS1/DVD MODE: 
---------------------

- Press CIRCLE on joypad 1.
 (This option is only needed just in case someone needs to force the PS2
  to boot in PS1/DVD mode).


FORCING AUTO MODE: 
---------------------

- Press CROSS on joypad 1.
  Useful to temporarily skip the default boot mode when set to something
  other than AUTO.


LAUNCHING MEMORY CARD APPLICATIONS:
-----------------------------------

- Press TRIANGLE on joypad 1.
- If installed, the Infinity Manager will appear and show a list of
  installed applications.

  -or-

- Press R1 on joypad 1.
- If installed, the default boot application (mc0:BOOT/BOOT.ELF) will
  be launched.




---

If you have any suggestion, or would like us to add some special or particual 
option, feel free to mail your suggestions at: info@infinitymod.com and
we will see if it will be possible to add it in the coming releases of the 
Infinity Firmware and/or the Infinity Manager.
