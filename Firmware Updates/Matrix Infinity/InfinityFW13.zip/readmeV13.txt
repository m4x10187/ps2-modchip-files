
======================
INFINITY FIRMWARE V1.3
======================


What's new :
------------

- ATAD auto patch.
- HDD browser support.
- PS2 color/videomode fix.
- GameAccellerator function for PAL machines (beta).
- Selectable default boot mode.
- Default language selection for FastBoot/MC applications.
- Selectable pad detect time.
- DEV1 compatible mode for MC applications.
- Infinity options configuration screen.


Notes :
-------

- ATAD auto patch will let you use your non-Sony hard disk like an original one
  (install HDD enabled games and updated browser software).

- The new HDD browser is now supported by the Infinity (no more need to fastboot
  games with the official or non-official HDD). 
  Owners of USA PS2 will be able to install and use the new official HDD Browser 
  coming with the HDDTools disk. 
  All discs will be recognized and autoboot.
   
- GameAccellerator (PAL60) experimental support. This forces all games to run
  on NTSC with color correction applied. Games will run faster (60Hz) but screen
  could be not centered (some games support adjusting of screen position if
  needed).

- You can now select a default boot mode. If no button is pressed on the pad this 
  boot mode will be used.

- You can now press R1 during boot to start DEV1 mode. This will launch
  applications on your memory card using the standard mc0:/BOOT/BOOT.ELF
  instead of the Infinity Manager.

- A default language to use for games using FastBoot or memory card applications
  can now be selected. Previously all games default to Japanese.

- On some PS2 versions if a pad was not connected on port0 the screen would stay
  black waiting for a pad for several seconds. This waiting time can now be
  configured (only useful if you usually boot your PS2 without any pad connected).



Infinity option configuration menu :
------------------------------------

Press TRIANGLE + CIRCLE to enter the configuration menu.


PS2 SCREEN FIX   : OFF    : Disables PS2 video fix.

                   COLOR  : Games will be output on their original video mode (PAL/NTSC)
                            with color correction applied to match your PS2 region.

                   VMODE  : Force video mode to match your PS2 region.

                   PAL60  : Force all games to NTSC with color correction.
                            Games will run faster but screen might need adjusting.

PSX SCREEN FIX   : ON/OFF : Enable/Disable PSX screen fix

MC16 PATCH       : ON/OFF : Enable/Disable D4TEL memory card support

ATAD AUTO PATCH  : ON/OFF : Enable/Disable ATAD auto patch

MACROVISION FIX  : ON/OFF : Enable/Disable Macrovision patch

GREEN FIX        : ON/OFF : Enable/Disable green correction on DVD movies

BOOT MODE        : AUTO   : Normal behaviour. All discs wil autoboot.

                   FAST   : FastBoot.
                            Same as pressing SELECT on boot.

                   INFMAN : Execute Infinity Manager on mc0:
                            Same as Pressing TRIANGLE on boot.

                   DEV1   : Execute BOOT.ELF on mc0:
                            Same as Pressing R1 on boot.
 
                   DVDV   : Force DVD video mode.
                            Same as Pressing CIRCLE on boot.

PAD DETECT TIME  : 2..10  : Select time to wait for connected pad on boot.
                            Only useful if pad is left unconnected.

DEFAULT LANGUAGE : LANG   : Default language to use for FastBoot/InfMan/Dev1 mode.




BURNING TO CD:
--------------

- Create a directory on your desktop or other location of your HD.
- Unzip the ".cue" and ".bin" files present inside the .zip file into this directory.
- Open your preferred burning program (Nero, alcohool120%, etc etc.) and choose
  option to burn a "CD-ROM ISO".
- Press the file selection button and choose file type "Image Files (.cue)".
- Navigate to the directory where you unzipped the V1.3 files and select the 
  "infv13.cue" file.
- Burn the CD.


UPGRADING INFINITY:
-------------------

- Insert the burned CD into the PS2 and press reset.
  The CD should boot authomatically and you will be presented with the Upgrade sreen.
- Follow instructions on screen to upgrade Infinity.

- NOTE : You can always recover from a bad flash by hoding the reset button until
  ====   the blue eject light turns on. This will let you boot the upgrade disc
         to reflash your Infinity.



STANDARD OPERATION FOR THE MATRIX INFINITY:
===========================================

BOOT OF PS2 / PS1 / DVD MOVIES: 
-------------------------------

- Insert the disc inside the PS2.
- The infinity will recognize the kind of disc you inserted and select
  the appropriate boot system.


TURNING OFF THE INFINITY:
-------------------------

- Press START on joypad 1 until the writing "DISABLED" will appear on screen. 
- Press reset once.
- The Infinity is now disabled until PS2 is turned off to Standby Position.


FAST BOOT OF PS2 GAMES: 
-----------------------

- Press SELECT on joypad 1.
- PS2 Logo will be skipped and game will boot directly.


FORCING PS1/DVD MODE: 
---------------------

- Press CIRCLE on joypad 1.
 (This option is only needed just in case someone needs to force the PS2
  to boot in PS1/DVD mode).


LAUNCHING MEMORY CARD APPLICATIONS:
-----------------------------------

- Press TRIANGLE on joypad 1.
- If installed, the Infinity Manager will appear and show a list of
  installed applications.

  -or-

- Press R1 on joypad 1.
- If installed, the default boot application (mc0:BOOT/BOOT.ELF) will
  be launched.




---

If you have any suggestion, or would like us to add some special or particual 
option, feel free to mail your suggestions at: info@infinitymod.com and
we will see if it will be possible to add it in the coming releases of the 
Infinity Firmware and/or the Infinity Manager.
