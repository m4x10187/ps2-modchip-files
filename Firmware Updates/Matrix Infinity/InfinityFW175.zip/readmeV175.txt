
=======================
INFINITY FIRMWARE V1.75
=======================


What's new :
------------

- VGA support added
- Main language loading fix


Notes :
-------

- VGA suport was added to this firmware relase. You can now use the original blaze
  vga adaptor without the boot cd and enjoy the enhanced games compatibility that
  this version brings you on your vga screen (with full original ps2 browser and
  dvd movies support in vga mode).

  VGA mode is set to 640x480 at 60Hz (so the added bonus is that PAL games will
  run 20% faster). Games are automatically centered according to the original
  resolution without vertical or horizontal side artifacts (a common problem
  with the original vga adapter).
  PSX games are not supported at the moment but will probably be in a future
  release (altough this is probably a low priority fix due to the small
  improvement that vga support could bring to psx games).

  When VGA mode is enabled you can access the monitor adjust screen in the config
  menu by pressing SELECT. You only need to do this the first time to adjust your
  monitor settings (a white border is present at the side of the screen, play with
  your monitor settings so that the 640x480 screen completely fills your viewing
  area).

  A schematic of the cable will be soon online on our site for those skilled
  in the art of patching things together ;)
  

- The language selected in the browser was not correctly loaded when BOOT MODE was
  set to DEV1. Program automatically loaded on boot from the memory card had the
  incorrect default language.



Infinity option configuration menu :
------------------------------------

Press TRIANGLE + CIRCLE to enter the configuration menu.


PS2 SCREEN FIX   : OFF    : Disables PS2 video fix.

                   COLOR  : Games will be output on their original video mode (PAL/NTSC)
                            with color correction applied to match your PS2 region.

                   PAL    : Force video mode to PAL

                   NTSC   : Force video mode to NTSC

                   PAL60  : Force all games to NTSC with color correction.
                            Games will run faster but screen might need adjusting.

                   VGA    : Enable 640x480 VGA mode.

Y SCREEN FIX     : OFF    : Y screen position fix is disabled.

                   AUTO   : Y position fix enabled with default settings.
                            Should be fine for most television sets. 

                   +/- N  : Fine tune Y position.
                            Positive values move the screen down, Negative values move it up.

PSX SCREEN FIX   : ON/OFF : Enable/Disable PSX screen fix

PSX MULTI DISK   : ON/OFF : Enable/Disable PSX multi disk support

MC16 PATCH       : ON/OFF : Enable/Disable D4TEL memory card support

ATAD AUTO PATCH  : ON/OFF : Enable/Disable ATAD auto patch

MACROVISION FIX  : ON/OFF : Enable/Disable Macrovision patch

GREEN FIX        : ON/OFF : Enable/Disable green correction on DVD movies

DVD VIDEO REGION : 1..8   : Selects the DVD player region.
                            Use it to match the corresponding region on RCE protected discs.

DVD9 DL SUPPORT  : ON/OFF : Enable/Disable Double Layer patch

BOOT MODE        : AUTO   : Normal behaviour. All discs wil autoboot.

                   FAST   : FastBoot.
                            Same as pressing SELECT on boot.

                   INFMAN : Execute Infinity Manager on mc0:
                            Same as Pressing TRIANGLE on boot.

                   DEV1   : Execute BOOT.ELF on mc0:
                            Same as Pressing R1 on boot.
 
                   DEV2   : Execute BOOT.ELF on HDD
                            Same as Pressing L1 on boot.
 
                   DVDV   : Force DVD video mode.
                            Same as Pressing CIRCLE on boot.

PAD DETECT TIME  : 2..10  : Select time to wait for connected pad on boot.
                            Only useful if pad is left unconnected.

BOOT LOGO        : ON/OFF : Enable/Disable Matrix boot logo.




BURNING TO CD:
--------------

- Create a directory on your desktop or other location of your HD.
- Unzip the ".cue" and ".bin" files present inside the .zip file into this directory.
- Open your preferred burning program (Nero, alcohool120%, etc etc.) and choose
  option to burn a "CD-ROM ISO".
- Press the file selection button and choose file type "Image Files (.cue)".
- Navigate to the directory where you unzipped the V1.75 files and select the 
  "infv175.cue" file.
- Burn the CD.


UPGRADING INFINITY:
-------------------

- Insert the burned CD into the PS2 and press reset.
  The CD should boot authomatically and you will be presented with the Upgrade sreen.
- Follow instructions on screen to upgrade Infinity.


**********************************************************************************

- NOTE  : You can always recover from a bad flash by entering recovery mode.
  ====    This will let you boot the upgrade disc to reflash your Infinity.

          To enter recovery mode:

          V1-V12 and V14 PAL :
          ====================

          Hold the reset button until the blue eject light turns on.
          

          V14+ USA and JAP
          ================

          USA : Hold reset until blue eject lights turn on, wait 3 seconds and
          tap reset again.

          JAP : Hold reset until blue eject lights turn on, wait 3 seconds and
          tap reset, wait 3 more seconds and tap reset again.

**********************************************************************************


STANDARD OPERATION FOR THE MATRIX INFINITY:
===========================================

BOOT OF PS2 / PS1 / DVD MOVIES: 
-------------------------------

- Insert the disc inside the PS2.
- The infinity will recognize the kind of disc you inserted and select
  the appropriate boot system.


TURNING OFF THE INFINITY:
-------------------------

- Press START on joypad 1 until the writing "DISABLED" will appear on screen. 
- Press reset once.
- The Infinity is now disabled until PS2 is turned off to Standby Position.


FAST BOOT OF PS2 GAMES: 
-----------------------

- Press SELECT on joypad 1.
- PS2 Logo will be skipped and game will boot directly.


FORCING PS1/DVD MODE: 
---------------------

- Press CIRCLE on joypad 1.
 (This option is only needed just in case someone needs to force the PS2
  to boot in PS1/DVD mode).


FORCING AUTO MODE: 
---------------------

- Press CROSS on joypad 1.
  Useful to temporarily skip the default boot mode when set to something
  other than AUTO.


LAUNCHING MEMORY CARD APPLICATIONS:
-----------------------------------

- Press TRIANGLE on joypad 1.
- If installed, the Infinity Manager will appear and show a list of
  installed applications.

  -or-

- Press R1/R2/L2 on joypad 1.
- This will launch the following applications according to the button pressed :
  
  R1 : "mc0:BOOT/BOOT.ELF"
  R2 : "mc0:BOOT/BOOT2.ELF"
  L2 : "mc0:BOOT/BOOT3.ELF"


LAUNCHING HDD APPLICATION (DEV2 MODE):
--------------------------------------

- Press L1 on joypad 1.
- If correctly installed, the default application will be executed from the HDD.




---

If you have any suggestion, or would like us to add some special or particual 
option, feel free to mail your suggestions at: info@infinitymod.com and
we will see if it will be possible to add it in the coming releases of the 
Infinity Firmware and/or the Infinity Manager.
