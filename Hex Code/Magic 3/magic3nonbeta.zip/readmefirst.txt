For all that requested it, this is the Magic3, it is the DV9-1 version, im not sure what revision it is, but it works!.  It works on all version's comments and flames are welcome.

Please test and let me know what you think, and if it worked ok for you.

I have included the SXH file, direct program for SX-KEY software and also a .hex for ICProg.

You might want to disassemble and analyse this, see what they changed

I might have fucked up when converting to hex, I havent got the time to do all this, so input on this is great, I have now included the following files,

magic3_DV9_1.sxh
magic3_DV9-1.hex
magic3d9.hex (unsure about this one, havent tried it?)

<<Tested version>>

V4 PAL Gap BIOS

V5 PAL No Gap

V7 PAL

Thanks

.....{{PS2Swap}}.....

rgvgs@hotmail.com

What you do with this is code is up to you, I do not take responsibilty for any damage you may do to your console, or any illegal activities you may conduct.